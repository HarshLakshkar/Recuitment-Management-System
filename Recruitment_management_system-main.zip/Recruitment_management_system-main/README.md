![image](https://github.com/user-attachments/assets/bec4ea8a-96fa-47a5-8589-3079b9895697)

 # MediBook 
 ## Note - some elements not added due to data security api sharing 
![image](https://github.com/user-attachments/assets/de55cb2d-2260-472a-8480-14cf05865e40)

 ---


![image](https://github.com/Shadowsweep/Assignment_1_django/assets/122604770/55bc73ef-174a-4a44-885a-938cda758315)

---
![image](https://github.com/Shadowsweep/Assignment_1_django/assets/122604770/32e5ca87-5c91-449c-83ab-f2f400042ada)

---

![image](https://github.com/Shadowsweep/Assignment_1_django/assets/122604770/3a6e0945-e507-45c9-9805-512a82e36739)
#   R e c r u i t m e n t _ m a n a g e m e n t _ s y s t e m  
 